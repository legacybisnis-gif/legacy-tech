module.exports = {
  Token: "8023006927:AAFDJvNrWuhhmSM1fpVqJUR4kbwAog_dSmA",
  owner: "7020308797",
};